FunkyStars Screen Saver for Windows
===================================
by Tursi - http://www.harmlesslion.com

It took me a few years to get around to it, but finally, here's a screen saver of my
'Funkystars' code.

To use it, copy it into your C:\Windows or C:\WINNT folder for 98/ME, or the \Windows\System32
or \Winnt\System32 folder for 2000 or XP. (Or, there, you can just right-click and select
'Install').

It will then show up in your regular list of screen savers.

There is a LOT of config - but you normally won't touch most of it. It's just there to
narrow the range of the random number generator. You might want to change the 'Change
Time' to make the patterns longer or shorter, and you might use the Radio buttons to
lock certain modes into play as you desire. For the rest, you can experiment or leave 
them be as you like.

The slider to the bottom right (under 'direction') sets the size of the stars - left for
smaller and right for larger. Smaller stars may be faster on some machines.

This new version moves config back to the registry cause it's simpler than dealing with Windows 10 permissions.

